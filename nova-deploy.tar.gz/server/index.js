import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import { db, initDb, seedUsers, verifyCredentials, save as dbSave, getAppSetting, setAppSetting } from './db.js';
import { v4 as uuid } from 'uuid';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SERVER_PKG = JSON.parse(fs.readFileSync(join(__dirname, 'package.json'), 'utf8'));
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: true }, pingTimeout: 60000 });

// Несколько сокетов на пользователя (веб + приложение) — синхронизация между вкладками/устройствами
const userSockets = new Map();

function emitToUser(userId, event, ...args) {
  const set = userSockets.get(userId);
  if (set) set.forEach((s) => { try { s.emit(event, ...args); } catch (e) { /* ignore */ } });
}

/** Всем сокетам пользователя, кроме одного (другие вкладки / устройства) */
function emitToUserExcept(userId, exceptSocket, event, payload) {
  const set = userSockets.get(userId);
  if (!set) return;
  set.forEach((s) => {
    if (exceptSocket != null && s === exceptSocket) return;
    try {
      s.emit(event, payload);
    } catch (e) { /* ignore */ }
  });
}

function emitSyncGroupsToGroupMembers(groupId) {
  try {
    const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
    members.forEach((m) => emitToUser(m.user_id, 'sync', { type: 'groups' }));
  } catch (e) { /* ignore */ }
}

// Группы, в которых идёт звонок: groupId -> userId инициатора
const activeGroupCalls = new Map();

const MAX_PINS_PER_CHAT = 5;

function messageBelongsToChat(messageRow, recipientType, recipientId, currentUserId) {
  if (!messageRow) return false;
  if (recipientType === 'group') {
    return messageRow.recipient_type === 'group' && String(messageRow.recipient_id) === String(recipientId);
  }
  const peer = String(recipientId);
  return messageRow.recipient_type === 'user' && (
    (messageRow.sender_id === currentUserId && messageRow.recipient_id === peer) ||
    (messageRow.sender_id === peer && messageRow.recipient_id === currentUserId)
  );
}

function userCanAccessChat(userId, recipientType, recipientId) {
  if (recipientType === 'group') {
    return !!db.prepare('SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?').get(recipientId, userId);
  }
  return String(userId) !== String(recipientId);
}

function canPinInChat(userId, recipientType, recipientId) {
  if (recipientType === 'user') return true;
  const m = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(recipientId, userId);
  return !!(m && m.role === 'admin');
}

function getReactionsGroupedByMessageIds(messageIds) {
  if (!messageIds.length) return {};
  const placeholders = messageIds.map(() => '?').join(',');
  let rows;
  try {
    rows = db.prepare(`SELECT message_id, user_id, emoji FROM message_reactions WHERE message_id IN (${placeholders})`).all(...messageIds);
  } catch (e) {
    return {};
  }
  const map = {};
  for (const r of rows) {
    if (!map[r.message_id]) map[r.message_id] = {};
    const em = r.emoji;
    if (!map[r.message_id][em]) map[r.message_id][em] = [];
    map[r.message_id][em].push(r.user_id);
  }
  return map;
}

function toClientReactions(groupedForMessage, userId) {
  const out = {};
  for (const [emoji, uids] of Object.entries(groupedForMessage || {})) {
    out[emoji] = { count: uids.length, me: uids.includes(userId) };
  }
  return out;
}

function emitToChatParticipants(recipientType, recipientId, event, payload, senderUserId) {
  if (recipientType === 'user') {
    const peer = String(recipientId);
    emitToUser(peer, event, payload);
    if (senderUserId) emitToUser(senderUserId, event, payload);
  } else {
    try {
      const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(recipientId);
      members.forEach((m) => emitToUser(m.user_id, event, payload));
    } catch (e) { /* ignore */ }
  }
}

function getPinnedListForChat(recipientType, recipientId) {
  try {
    const rows = db.prepare(`
      SELECT p.message_id AS id, p.pinned_at, m.content, m.sender_id, m.created_at, m.attachment_path, m.is_deleted
      FROM pinned_messages p
      JOIN messages m ON m.id = p.message_id
      WHERE p.recipient_type = ? AND p.recipient_id = ?
      ORDER BY p.pinned_at ASC
    `).all(recipientType, recipientId);
    return rows.map((r) => {
      const sender = db.prepare('SELECT display_name FROM users WHERE id = ?').get(r.sender_id);
      return {
        id: r.id,
        content: Number(r.is_deleted) === 1 ? '' : (r.content || ''),
        senderName: sender?.display_name || '',
        createdAt: r.created_at,
        attachmentPath: r.attachment_path || null,
        isDeleted: Number(r.is_deleted) === 1,
      };
    });
  } catch (e) {
    return [];
  }
}

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use((err, req, res, next) => {
  if (err) {
    console.error('[SERVER] JSON/body parse error:', err.message);
    res.status(400).json({ error: 'Invalid request body: ' + err.message });
    return;
  }
  next();
});
if (!fs.existsSync(join(__dirname, 'uploads'))) fs.mkdirSync(join(__dirname, 'uploads'));
app.use('/uploads', express.static(join(__dirname, 'uploads')));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_, __, cb) => cb(null, join(__dirname, 'uploads')),
    filename: (_, file, cb) => cb(null, Date.now() + '-avatar.png'),
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    if (!file.mimetype || !file.mimetype.startsWith('image/')) {
      cb(new Error('Only image files are allowed'));
      return;
    }
    cb(null, true);
  },
});

const uploadVoice = multer({
  storage: multer.diskStorage({
    destination: (_, __, cb) => cb(null, join(__dirname, 'uploads')),
    filename: (_, file, cb) => cb(null, Date.now() + '-voice.' + (file.originalname?.split('.').pop() || 'webm')),
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    const mt = (file.mimetype || '').toLowerCase();
    const ok = mt.startsWith('audio/') || mt === 'video/webm' || mt === 'application/octet-stream' || !mt;
    if (!ok) {
      cb(new Error('Only audio files are allowed'));
      return;
    }
    cb(null, true);
  },
});

const uploadAttachment = multer({
  storage: multer.diskStorage({
    destination: (_, __, cb) => cb(null, join(__dirname, 'uploads')),
    filename: (_, file, cb) => {
      const ext = (file.originalname && file.originalname.split('.').pop()) || 'bin';
      const safe = ext.replace(/[^a-z0-9]/gi, '') || 'bin';
      cb(null, Date.now() + '-att.' + safe);
    },
  }),
  limits: { fileSize: 50 * 1024 * 1024 },
});

// Инициализация БД и создание аккаунтов
await initDb();
  await seedUsers();

// Миграция: фон группы
try {
  db.prepare('SELECT background_path FROM groups LIMIT 1').get();
} catch (e) {
  try {
    db.exec('ALTER TABLE groups ADD COLUMN background_path TEXT');
  } catch (err) {
    console.warn('Migration background_path:', err.message);
  }
}

// Логирование запросов (без сериализации body, чтобы не падать)
app.use('/api', (req, res, next) => {
  try {
    console.log(`[API] ${req.method} ${req.path}`);
  } catch (e) {
    console.error('[API] Log error:', e.message);
  }
  next();
});

// Middleware для проверки токена
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  const token = auth && auth.startsWith('Bearer ') ? auth.slice(7) : null;
  
  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString());
    if (!payload.userId) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    req.userId = payload.userId;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token format' });
  }
}

function isAdminUserId(userId) {
  try {
    const row = db.prepare('SELECT login FROM users WHERE id = ?').get(userId);
    return row && row.login === 'lololowkid';
  } catch (e) {
    console.error('isAdminUserId error:', e.message);
    return false;
  }
}

function adminMiddleware(req, res, next) {
  if (!req.userId || !isAdminUserId(req.userId)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

/** Смена юзернейма: для всех по флагу; главный админ (lololowkid) всегда может. */
function isAllowUsernameChangeForUser(login) {
  if (!login || typeof login !== 'string') return false;
  if (login === 'lololowkid') return true;
  return getAppSetting('allow_username_change_all', '1') === '1';
}

// Генерация токена
function generateToken(userId) {
  const payload = { userId, at: Date.now() };
  return Buffer.from(JSON.stringify(payload)).toString('base64');
}

// Генерация кода подтверждения (6 цифр)
function generateVerificationCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Отправка кода подтверждения на телефон
app.post('/api/auth/send-verification-code', (req, res) => {
  const send = (status, body) => {
    if (res.headersSent) return;
    try {
      res.status(status).json(typeof body === 'object' ? body : { error: String(body) });
    } catch (e) {
      console.error('[SEND_CODE] send failed:', e.message);
    }
  };

  try {
    const body = req.body || {};
    const phone = body.phone;

    if (!phone || typeof phone !== 'string' || !phone.trim()) {
      return send(400, 'Phone number is required');
    }

    // Нормализуем номер телефона (убираем все кроме цифр и +)
    const normalizedPhone = phone.replace(/[^\d+]/g, '');
    
    // Простая валидация формата (минимум 10 цифр)
    const digitsOnly = normalizedPhone.replace(/\+/g, '');
    if (digitsOnly.length < 10) {
      return send(400, 'Invalid phone number format');
    }

    // Генерируем код
    const code = generateVerificationCode();
    const expiresAt = Math.floor(Date.now() / 1000) + 300; // Код действителен 5 минут

    // Сохраняем код в БД
    try {
      db.prepare(`
        INSERT INTO phone_verification_codes (phone, code, expires_at, attempts)
        VALUES (?, ?, ?, 0)
        ON CONFLICT(phone) DO UPDATE SET
          code = ?,
          expires_at = ?,
          attempts = 0,
          created_at = strftime('%s','now')
      `).run(normalizedPhone, code, expiresAt, code, expiresAt);
    } catch (dbErr) {
      console.error('[SEND_CODE] DB error:', dbErr.message);
      return send(500, 'Database error: ' + String(dbErr.message));
    }

    // В реальном приложении здесь была бы отправка SMS через Twilio, AWS SNS и т.д.
    // Для разработки выводим код в консоль
    console.log(`[SMS] Verification code for ${normalizedPhone}: ${code}`);
    console.log(`[SMS] Code expires at: ${new Date(expiresAt * 1000).toLocaleString()}`);

    // В продакшене здесь был бы вызов SMS API
    // Например: await twilioClient.messages.create({ to: phone, body: `Your verification code: ${code}` });

    return send(200, { 
      message: 'Verification code sent',
      // В режиме разработки возвращаем код для тестирования
      code: process.env.NODE_ENV === 'development' ? code : undefined
    });
  } catch (err) {
    console.error('[SEND_CODE] Error:', err.message, err.stack);
    return send(500, 'Server error: ' + (err.message || 'Unknown'));
  }
});

// Проверка кода подтверждения
app.post('/api/auth/verify-phone-code', (req, res) => {
  const send = (status, body) => {
    if (res.headersSent) return;
    try {
      res.status(status).json(typeof body === 'object' ? body : { error: String(body) });
    } catch (e) {
      console.error('[VERIFY_CODE] send failed:', e.message);
    }
  };

  try {
    const body = req.body || {};
    const phone = body.phone;
    const code = body.code;

    if (!phone || typeof phone !== 'string' || !phone.trim()) {
      return send(400, 'Phone number is required');
    }
    if (!code || typeof code !== 'string' || !code.trim()) {
      return send(400, 'Verification code is required');
    }

    const normalizedPhone = phone.replace(/[^\d+]/g, '');
    const trimmedCode = code.trim();

    // Получаем код из БД
    let verification;
    try {
      verification = db.prepare('SELECT code, expires_at, attempts FROM phone_verification_codes WHERE phone = ?').get(normalizedPhone);
    } catch (dbErr) {
      console.error('[VERIFY_CODE] DB error:', dbErr.message);
      return send(500, 'Database error: ' + String(dbErr.message));
    }

    if (!verification) {
      return send(400, 'Verification code not found. Please request a new code.');
    }

    // Проверяем количество попыток (максимум 5)
    if (verification.attempts >= 5) {
      return send(400, 'Too many attempts. Please request a new code.');
    }

    // Проверяем срок действия
    const now = Math.floor(Date.now() / 1000);
    if (verification.expires_at < now) {
      return send(400, 'Verification code expired. Please request a new code.');
    }

    // Увеличиваем счетчик попыток
    db.prepare('UPDATE phone_verification_codes SET attempts = attempts + 1 WHERE phone = ?').run(normalizedPhone);

    // Проверяем код
    if (verification.code !== trimmedCode) {
      return send(400, 'Invalid verification code');
    }

    // Код верный - удаляем его из БД
    db.prepare('DELETE FROM phone_verification_codes WHERE phone = ?').run(normalizedPhone);

    return send(200, { verified: true, message: 'Phone number verified successfully' });
  } catch (err) {
    console.error('[VERIFY_CODE] Error:', err.message, err.stack);
    return send(500, 'Server error: ' + (err.message || 'Unknown'));
  }
});

// Регистрация нового пользователя
app.post('/api/auth/register', (req, res) => {
  const send = (status, body) => {
    if (res.headersSent) return;
    try {
      res.status(status).json(typeof body === 'object' ? body : { error: String(body) });
    } catch (e) {
      console.error('[REGISTER] send failed:', e.message);
    }
  };

  try {
    const body = req.body || {};
    const login = body.login;
    const password = body.password;
    const displayName = body.displayName;
    const phone = body.phone;
    const verificationCode = body.verificationCode;

    if (!login || typeof login !== 'string' || !String(login).trim()) {
      return send(400, 'Login is required');
    }
    if (!password || typeof password !== 'string') {
      return send(400, 'Password is required');
    }
    if (password.length < 4) {
      return send(400, 'Password must be at least 4 characters');
    }
    if (!displayName || typeof displayName !== 'string' || !String(displayName).trim()) {
      return send(400, 'Display name is required');
    }
    if (!phone || typeof phone !== 'string' || !phone.trim()) {
      return send(400, 'Phone number is required');
    }
    if (!verificationCode || typeof verificationCode !== 'string' || !verificationCode.trim()) {
      return send(400, 'Verification code is required');
    }

    const trimmedLogin = String(login).trim();
    const trimmedDisplayName = String(displayName).trim();
    const normalizedPhone = phone.replace(/[^\d+]/g, '');
    const trimmedCode = verificationCode.trim();

    // Проверка формата логина
    if (!/^[a-zA-Z0-9_]+$/.test(trimmedLogin)) {
      return send(400, 'Login can only contain letters, numbers, and underscores');
    }
    if (trimmedLogin.length > 30) {
      return send(400, 'Login must be 30 characters or less');
    }
    if (trimmedDisplayName.length > 50) {
      return send(400, 'Display name must be 50 characters or less');
    }

    // Проверка формата телефона
    const digitsOnly = normalizedPhone.replace(/\+/g, '');
    if (digitsOnly.length < 10) {
      return send(400, 'Invalid phone number format');
    }

    // Проверяем код подтверждения перед регистрацией
    let verification;
    try {
      verification = db.prepare('SELECT code, expires_at, attempts FROM phone_verification_codes WHERE phone = ?').get(normalizedPhone);
    } catch (dbErr) {
      console.error('[REGISTER] DB verification check error:', dbErr.message);
      return send(500, 'Database error: ' + String(dbErr.message));
    }

    if (!verification) {
      return send(400, 'Verification code not found. Please verify your phone number first.');
    }

    if (verification.attempts >= 5) {
      return send(400, 'Too many verification attempts. Please request a new code.');
    }

    const now = Math.floor(Date.now() / 1000);
    if (verification.expires_at < now) {
      return send(400, 'Verification code expired. Please request a new code.');
    }

    if (verification.code !== trimmedCode) {
      db.prepare('UPDATE phone_verification_codes SET attempts = attempts + 1 WHERE phone = ?').run(normalizedPhone);
      return send(400, 'Invalid verification code');
    }

    // Проверка уникальности логина
    let existing;
    try {
      existing = db.prepare('SELECT id FROM users WHERE login = ?').get(trimmedLogin);
    } catch (dbErr) {
      console.error('[REGISTER] DB error:', dbErr.message);
      return send(500, 'Database error: ' + String(dbErr.message));
    }

    if (existing) {
      return send(400, 'This login is already taken');
    }

    // Проверка уникальности телефона
    let existingPhone;
    try {
      existingPhone = db.prepare('SELECT id FROM users WHERE phone = ?').get(normalizedPhone);
    } catch (dbErr) {
      console.error('[REGISTER] DB phone check error:', dbErr.message);
      return send(500, 'Database error: ' + String(dbErr.message));
    }

    if (existingPhone) {
      return send(400, 'This phone number is already registered');
    }

    // Создаём нового пользователя
    const userId = uuid();
    try {
      db.prepare('INSERT INTO users (id, login, password, display_name, phone, phone_verified) VALUES (?, ?, ?, ?, ?, 1)').run(
        userId,
        trimmedLogin,
        password,
        trimmedDisplayName,
        normalizedPhone
      );
    } catch (dbErr) {
      console.error('[REGISTER] DB insert error:', dbErr.message);
      if (dbErr.message && dbErr.message.includes('UNIQUE constraint failed')) {
        if (dbErr.message.includes('login')) {
          return send(400, 'This login is already taken');
        }
        if (dbErr.message.includes('phone')) {
          return send(400, 'This phone number is already registered');
        }
      }
      return send(500, 'Database error: ' + String(dbErr.message));
    }

    // Удаляем использованный код подтверждения
    db.prepare('DELETE FROM phone_verification_codes WHERE phone = ?').run(normalizedPhone);

    const token = generateToken(userId);
    const user = {
      id: userId,
      login: trimmedLogin,
      displayName: trimmedDisplayName,
      bio: '',
      avatarPath: null,
      allowUsernameChange: isAllowUsernameChangeForUser(trimmedLogin),
    };

    console.log('[REGISTER] New user created:', trimmedLogin, 'Phone:', normalizedPhone);
    return send(200, { token, user });
  } catch (err) {
    console.error('[REGISTER] Error:', err.message, err.stack);
    return send(500, 'Server error: ' + (err.message || 'Unknown'));
  }
});

// Тестовый endpoint
app.get('/api/test', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running', timestamp: Date.now() });
});

app.get('/api/version', (req, res) => {
  res.json({
    ok: true,
    version: SERVER_PKG.version,
    name: SERVER_PKG.name,
  });
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, t: Date.now() });
});

// Тестовый endpoint для проверки маршрута групп
app.get('/api/groups/test', authMiddleware, (req, res) => {
  res.json({ status: 'ok', message: 'Groups route is working', userId: req.userId });
});

// Аутентификация — всегда отправляем ответ с телом
app.post('/api/auth/login', (req, res) => {
  const send = (status, body) => {
    if (res.headersSent) return;
    try {
      res.status(status).json(typeof body === 'object' ? body : { error: String(body) });
    } catch (e) {
      console.error('[LOGIN] send failed:', e.message);
    }
  };

  try {
    const body = req.body || {};
    const login = body.login;
    const password = body.password;

    if (!login || typeof login !== 'string' || !String(login).trim()) {
      return send(400, 'Login is required');
    }
    if (!password || typeof password !== 'string') {
      return send(400, 'Password is required');
    }

    const trimmedLogin = String(login).trim();

    let row;
    try {
      row = db.prepare('SELECT id, login, password, display_name, bio, avatar_path, ban_until, is_verified FROM users WHERE login = ?').get(trimmedLogin);
    } catch (dbErr) {
      console.error('[LOGIN] DB error:', dbErr.message);
      return send(500, 'Database error: ' + String(dbErr.message));
    }

    if (!row) {
      return send(401, 'Invalid login or password');
    }

    if (row.password !== password) {
      return send(401, 'Invalid login or password');
    }

    const nowSec = Math.floor(Date.now() / 1000);
    if (typeof row.ban_until === 'number' && row.ban_until > nowSec) {
      return send(403, `Account is banned until ${new Date(row.ban_until * 1000).toISOString()}`);
    }

    const token = generateToken(row.id);
    const user = {
      id: row.id,
      login: row.login,
      displayName: row.display_name || row.login,
      bio: row.bio ?? '',
      avatarPath: row.avatar_path ?? null,
      allowUsernameChange: isAllowUsernameChangeForUser(row.login),
    };

    return send(200, { token, user });
  } catch (err) {
    console.error('[LOGIN] Error:', err.message, err.stack);
    return send(500, 'Server error: ' + (err.message || 'Unknown'));
  }
});

// Получение списка пользователей
app.get('/api/users', authMiddleware, (req, res) => {
  try {
    const users = db.prepare('SELECT id, login, display_name, bio, avatar_path, is_verified, ban_until, e2e_public_key FROM users ORDER BY display_name').all();
    res.json(users.map(u => ({
      id: u.id,
      login: u.login,
      displayName: u.display_name,
      bio: u.bio || '',
      avatarPath: u.avatar_path,
      isVerified: !!u.is_verified,
      banUntil: typeof u.ban_until === 'number' ? u.ban_until : null,
      e2ePublicKey: u.e2e_public_key || null,
    })));
  } catch (err) {
    console.error('Get users error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Наличие пользователя (онлайн / был в сети)
app.get('/api/users/:id/presence', authMiddleware, (req, res) => {
  try {
    const targetId = req.params.id;
    const row = db.prepare('SELECT last_seen_at, hide_last_seen FROM users WHERE id = ?').get(targetId);
    if (!row) return res.status(404).json({ error: 'User not found' });
    const online = userSockets.has(targetId);
    const hideLastSeen = !!row.hide_last_seen;
    res.json({
      online,
      lastSeenAt: hideLastSeen && !online ? null : (row.last_seen_at || null),
      hideLastSeen,
    });
  } catch (err) {
    console.error('Presence error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение профиля текущего пользователя
app.get('/api/users/me', authMiddleware, (req, res) => {
  try {
    const user = db.prepare('SELECT id, login, display_name, bio, avatar_path, hide_last_seen, is_verified, ban_until, e2e_public_key FROM users WHERE id = ?').get(req.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({
      id: user.id,
      login: user.login,
      displayName: user.display_name,
      bio: user.bio || '',
      avatarPath: user.avatar_path,
      hideLastSeen: !!user.hide_last_seen,
      isVerified: !!user.is_verified,
      banUntil: typeof user.ban_until === 'number' ? user.ban_until : null,
      e2ePublicKey: user.e2e_public_key || null,
      allowUsernameChange: isAllowUsernameChangeForUser(user.login),
    });
  } catch (err) {
    console.error('Get user profile error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Обновление профиля
app.put('/api/users/me', authMiddleware, (req, res) => {
  try {
    console.log('[UPDATE PROFILE] Request body:', JSON.stringify(req.body));
    const { login, displayName, bio, hideLastSeen } = req.body || {};
    console.log('[UPDATE PROFILE] Extracted login from body:', login, 'type:', typeof login);
    const current = db.prepare('SELECT login, display_name, bio, hide_last_seen FROM users WHERE id = ?').get(req.userId);
    console.log('[UPDATE PROFILE] Current user login:', current?.login);
    if (!current) return res.status(404).json({ error: 'User not found' });
    let loginVal = current.login;
    let display_name = current.display_name;
    let bioVal = current.bio;
    let hide_last_seen_val = current.hide_last_seen != null ? current.hide_last_seen : 0;
    
    // Обновление логина
    if (login !== undefined && login !== null) {
      console.log('[UPDATE PROFILE] Login update requested:', { current: current.login, new: login });
      if (!login || typeof login !== 'string' || !login.trim()) {
        return res.status(400).json({ error: 'Username is required' });
      }
      const trimmedLogin = login.trim();
      // Проверка формата юзернейма (только буквы, цифры, подчеркивания)
      if (!/^[a-zA-Z0-9_]+$/.test(trimmedLogin)) {
        return res.status(400).json({ error: 'Username can only contain letters, numbers, and underscores' });
      }
      if (trimmedLogin.length > 30) {
        return res.status(400).json({ error: 'Username must be 30 characters or less' });
      }
      // Проверка уникальности логина (если изменился)
      if (trimmedLogin !== current.login) {
        if (!isAllowUsernameChangeForUser(current.login)) {
          return res.status(403).json({ error: 'Username change is disabled by the administrator' });
        }
        console.log('[UPDATE PROFILE] Login changed, checking uniqueness...');
        const existing = db.prepare('SELECT id FROM users WHERE login = ?').get(trimmedLogin);
        if (existing && existing.id !== req.userId) {
          console.log('[UPDATE PROFILE] Login already taken by user:', existing.id);
          return res.status(400).json({ error: 'This login is already taken' });
        }
        loginVal = trimmedLogin;
        console.log('[UPDATE PROFILE] Login will be updated to:', loginVal);
      } else {
        console.log('[UPDATE PROFILE] Login unchanged, keeping:', current.login);
      }
    } else {
      console.log('[UPDATE PROFILE] Login not provided, keeping current:', current.login);
    }
    
    if (displayName !== undefined) {
      if (!displayName || typeof displayName !== 'string' || !displayName.trim()) {
        return res.status(400).json({ error: 'Display name is required' });
      }
      display_name = displayName.trim();
    }
    if (bio !== undefined) bioVal = bio ? String(bio).trim() : null;
    if (typeof hideLastSeen === 'boolean') hide_last_seen_val = hideLastSeen ? 1 : 0;
    
    console.log('[UPDATE PROFILE] About to update DB with login:', loginVal, 'for user:', req.userId);
    db.prepare('UPDATE users SET login = ?, display_name = ?, bio = ?, hide_last_seen = ? WHERE id = ?').run(loginVal, display_name, bioVal, hide_last_seen_val, req.userId);
    const updated = db.prepare('SELECT id, login, display_name, bio, avatar_path, hide_last_seen, is_verified, ban_until, e2e_public_key FROM users WHERE id = ?').get(req.userId);
    console.log('[UPDATE PROFILE] Updated user from DB:', { id: updated.id, login: updated.login, displayName: updated.display_name });
    console.log('[UPDATE PROFILE] Sending response with login:', updated.login);
    emitToUser(req.userId, 'sync', { type: 'profile' });
    const response = {
      id: updated.id,
      login: updated.login,
      displayName: updated.display_name,
      bio: updated.bio || '',
      avatarPath: updated.avatar_path,
      hideLastSeen: !!updated.hide_last_seen,
      isVerified: !!updated.is_verified,
      banUntil: typeof updated.ban_until === 'number' ? updated.ban_until : null,
      e2ePublicKey: updated.e2e_public_key || null,
      allowUsernameChange: isAllowUsernameChangeForUser(updated.login),
    };
    console.log('[UPDATE PROFILE] Response object:', JSON.stringify(response));
    res.json(response);
  } catch (err) {
    console.error('Update profile error:', err);
    if (err.message && err.message.includes('UNIQUE constraint failed')) {
      return res.status(400).json({ error: 'This username is already taken' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Установка публичного ключа для сквозного шифрования
app.put('/api/users/me/e2e-key', authMiddleware, (req, res) => {
  try {
    const { publicKey } = req.body || {};
    if (!publicKey || typeof publicKey !== 'string' || publicKey.length > 8000) {
      return res.status(400).json({ error: 'Invalid public key' });
    }
    db.prepare('UPDATE users SET e2e_public_key = ? WHERE id = ?').run(publicKey, req.userId);
    const row = db.prepare('SELECT e2e_public_key FROM users WHERE id = ?').get(req.userId);
    res.json({ e2ePublicKey: row?.e2e_public_key || null });
  } catch (err) {
    console.error('Set e2e key error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Загрузка аватара
app.post('/api/users/avatar', authMiddleware, upload.single('avatar'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
  const avatarPath = '/uploads/' + req.file.filename;
  db.prepare('UPDATE users SET avatar_path = ? WHERE id = ?').run(avatarPath, req.userId);
    emitToUser(req.userId, 'sync', { type: 'profile' });
  res.json({ avatarPath });
  } catch (err) {
    console.error('Avatar upload error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// CORS preflight для загрузки фона чата
app.options('/api/users/me/chat-background', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.sendStatus(204);
});

// Фон чата (своё фото) — только для отображения у себя
app.post('/api/users/me/chat-background', authMiddleware, upload.single('background'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const path = '/uploads/' + req.file.filename;
    res.json({ path });
  } catch (err) {
    console.error('Chat background upload error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Заблокировать пользователя
app.post('/api/users/me/block/:userId', authMiddleware, (req, res) => {
  try {
    const { userId } = req.params;
    if (!userId || userId === req.userId) return res.status(400).json({ error: 'Invalid user' });
    try {
      db.prepare('INSERT INTO blocks (user_id, blocked_user_id) VALUES (?, ?)').run(req.userId, userId);
    } catch (e) {
      if (!e.message || !e.message.includes('UNIQUE')) throw e;
    }
    res.json({ ok: true });
  } catch (err) {
    console.error('Block user error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Разблокировать
app.delete('/api/users/me/block/:userId', authMiddleware, (req, res) => {
  try {
    const { userId } = req.params;
    if (!userId) return res.status(400).json({ error: 'Invalid user' });
    db.prepare('DELETE FROM blocks WHERE user_id = ? AND blocked_user_id = ?').run(req.userId, userId);
    res.json({ ok: true });
  } catch (err) {
    console.error('Unblock error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Список заблокированных
app.get('/api/users/me/blocked', authMiddleware, (req, res) => {
  try {
    const rows = db.prepare('SELECT blocked_user_id FROM blocks WHERE user_id = ?').all(req.userId);
    res.json(rows.map((r) => r.blocked_user_id));
  } catch (err) {
    console.error('Get blocked error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// CORS preflight для DELETE личного чата и блокировки
app.options('/api/messages/direct/:userId', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.sendStatus(204);
});
app.options('/api/users/me/block/:userId', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.sendStatus(204);
});

// Удалить личную переписку с пользователем (все сообщения между мной и userId)
app.delete('/api/messages/direct/:userId', authMiddleware, (req, res) => {
  try {
    const { userId } = req.params;
    if (!userId || userId === req.userId) return res.status(400).json({ error: 'Invalid user' });
    db.prepare(`
      DELETE FROM messages
      WHERE recipient_type = 'user' AND (
        (sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?)
      )
    `).run(req.userId, userId, userId, req.userId);
    res.json({ ok: true });
  } catch (err) {
    console.error('Delete direct chat error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// CORS preflight для голосовых (чтобы браузер не получал 404 на OPTIONS)
app.options('/api/voice/upload', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.sendStatus(204);
});

// Загрузка вложений (фото, видео, файлы) для чата
app.options('/api/attachments/upload', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Max-Age', '86400');
  res.sendStatus(204);
});
app.post('/api/attachments/upload', authMiddleware, (req, res, next) => {
  uploadAttachment.single('file')(req, res, (err) => {
    if (err) {
      const msg = err.code === 'LIMIT_FILE_SIZE' ? 'Файл слишком большой (макс. 50 МБ)' : (err.message || 'Upload failed');
      return res.status(400).json({ error: msg });
    }
    if (!req.file) return res.status(400).json({ error: 'No file' });
    try {
      res.json({ path: '/uploads/' + req.file.filename });
    } catch (e) {
      res.status(500).json({ error: 'Upload failed' });
    }
  });
});

// Загрузка голосового сообщения
app.post('/api/voice/upload', authMiddleware, (req, res, next) => {
  uploadVoice.single('voice')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message || 'Voice upload failed' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No audio file' });
    }
    res.json({ path: '/uploads/' + req.file.filename });
  });
});

function emitSyncServersToUsers(userIds) {
  [...new Set(userIds)].filter(Boolean).forEach((uid) => {
    emitToUser(uid, 'sync', { type: 'servers' });
    emitToUser(uid, 'sync', { type: 'groups' });
  });
}

// Список серверов (Discord-style)
app.get('/api/servers', authMiddleware, (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT s.id, s.name, s.icon_path, s.created_by, s.created_at, sm.role AS my_role
      FROM servers s
      INNER JOIN server_members sm ON sm.server_id = s.id AND sm.user_id = ?
      ORDER BY s.created_at ASC
    `).all(req.userId);
    res.json(rows.map((s) => ({
      id: s.id,
      name: s.name,
      iconPath: s.icon_path || null,
      createdBy: s.created_by,
      createdAt: s.created_at,
      myRole: s.my_role || 'member',
    })));
  } catch (err) {
    console.error('Get servers error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/servers', authMiddleware, (req, res) => {
  try {
    const { name } = req.body || {};
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'Server name is required' });
    }
    const serverId = uuid();
    db.prepare('INSERT INTO servers (id, name, created_by) VALUES (?, ?, ?)').run(serverId, name.trim(), req.userId);
    db.prepare('INSERT INTO server_members (server_id, user_id, role) VALUES (?, ?, ?)').run(serverId, req.userId, 'admin');
    dbSave();
    emitSyncServersToUsers([req.userId]);
    res.json({ id: serverId, name: name.trim() });
  } catch (err) {
    console.error('Create server error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/servers/:serverId/channels', authMiddleware, (req, res) => {
  try {
    const { serverId } = req.params;
    const { name } = req.body || {};
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'Channel name is required' });
    }
    const m = db.prepare('SELECT role FROM server_members WHERE server_id = ? AND user_id = ?').get(serverId, req.userId);
    if (!m || m.role !== 'admin') {
      return res.status(403).json({ error: 'Only server admins can create channels' });
    }
    const memberRows = db.prepare('SELECT user_id FROM server_members WHERE server_id = ?').all(serverId);
    if (!memberRows.length) return res.status(400).json({ error: 'Server has no members' });

    const groupId = uuid();
    try {
      db.prepare('INSERT INTO groups (id, name, created_by, avatar_path, server_id) VALUES (?, ?, ?, ?, ?)').run(groupId, name.trim(), req.userId, null, serverId);
    } catch (e) {
      try {
        db.prepare('INSERT INTO groups (id, name, created_by, server_id) VALUES (?, ?, ?, ?)').run(groupId, name.trim(), req.userId, serverId);
      } catch (e2) {
        db.prepare('INSERT INTO groups (id, name, created_by) VALUES (?, ?, ?)').run(groupId, name.trim(), req.userId);
        try {
          db.prepare('UPDATE groups SET server_id = ? WHERE id = ?').run(serverId, groupId);
        } catch (e3) { /* ignore */ }
      }
    }

    let addMember;
    try {
      addMember = db.prepare('INSERT INTO group_members (group_id, user_id, role) VALUES (?, ?, ?)');
    } catch (e) {
      addMember = db.prepare('INSERT INTO group_members (group_id, user_id) VALUES (?, ?)');
    }
    memberRows.forEach(({ user_id }) => {
      const role = user_id === req.userId ? 'admin' : 'member';
      try {
        addMember.run(groupId, user_id, role);
      } catch (e2) {
        try {
          db.prepare('INSERT INTO group_members (group_id, user_id) VALUES (?, ?)').run(groupId, user_id);
        } catch (e3) { /* ignore duplicate */ }
      }
    });
    dbSave();
    const notifyIds = memberRows.map((r) => r.user_id);
    notifyIds.forEach((uid) => emitToUser(uid, 'sync', { type: 'groups' }));
    emitSyncServersToUsers(notifyIds);
    res.json({ id: groupId, name: name.trim(), serverId });
  } catch (err) {
    console.error('Create channel error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/servers/:serverId/members', authMiddleware, (req, res) => {
  try {
    const { serverId } = req.params;
    const { userIds } = req.body || {};
    if (!Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ error: 'userIds array required' });
    }
    const m = db.prepare('SELECT role FROM server_members WHERE server_id = ? AND user_id = ?').get(serverId, req.userId);
    if (!m || m.role !== 'admin') {
      return res.status(403).json({ error: 'Only server admins can invite' });
    }
    const channelRows = db.prepare('SELECT id FROM groups WHERE server_id = ?').all(serverId);
    const toNotify = new Set();
    userIds.forEach((uid) => {
      if (!uid || typeof uid !== 'string') return;
      try {
        db.prepare('INSERT OR IGNORE INTO server_members (server_id, user_id, role) VALUES (?, ?, ?)').run(serverId, uid, 'member');
        toNotify.add(uid);
      } catch (e) { /* ignore */ }
      channelRows.forEach((ch) => {
        try {
          db.prepare('INSERT OR IGNORE INTO group_members (group_id, user_id, role) VALUES (?, ?, ?)').run(ch.id, uid, 'member');
        } catch (e2) {
          try {
            db.prepare('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)').run(ch.id, uid);
          } catch (e3) { /* ignore */ }
        }
      });
    });
    dbSave();
    [...toNotify].forEach((uid) => emitToUser(uid, 'sync', { type: 'groups' }));
    emitSyncServersToUsers([...toNotify]);
    res.json({ ok: true });
  } catch (err) {
    console.error('Server invite error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение списка групп
app.get('/api/groups', authMiddleware, (req, res) => {
  try {
    let rows;
    try {
      rows = db.prepare(`
        SELECT g.id, g.name, g.avatar_path, g.background_path, g.created_by, g.created_at, g.server_id, gm.role AS my_role
        FROM groups g 
        INNER JOIN group_members gm ON gm.group_id = g.id 
        WHERE gm.user_id = ? 
        ORDER BY g.created_at DESC
      `).all(req.userId);
    } catch (e) {
      rows = db.prepare(`
        SELECT g.id, g.name, g.avatar_path, g.background_path, g.created_by, g.created_at, gm.role AS my_role
        FROM groups g 
        INNER JOIN group_members gm ON gm.group_id = g.id 
        WHERE gm.user_id = ? 
        ORDER BY g.created_at DESC
      `).all(req.userId);
    }
    
    res.json(rows.map(g => ({
      id: g.id,
      name: g.name,
      avatarPath: g.avatar_path || null,
      backgroundPath: g.background_path || null,
      createdBy: g.created_by,
      createdAt: g.created_at,
      myRole: g.my_role || 'member',
      serverId: g.server_id || null,
    })));
  } catch (err) {
    console.error('Get groups error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение информации о группе (ВАЖНО: должен быть ПЕРЕД /api/groups/:id/members)
app.get('/api/groups/:id', authMiddleware, (req, res) => {
  console.log('=== GROUP ROUTE HIT ===');
  console.log('req.params:', req.params);
  console.log('req.path:', req.path);
  console.log('req.url:', req.url);
  try {
    const groupId = req.params.id;
    console.log(`[GET /api/groups/${groupId}] Request received, userId: ${req.userId}`);
    
    // Проверяем, что пользователь является участником группы
    let member;
    try {
      member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, req.userId);
      console.log(`[GET /api/groups/${groupId}] Member check result:`, member);
    } catch (e) {
      console.warn(`[GET /api/groups/${groupId}] Role check failed, trying without role:`, e.message);
      // Если поле role не существует, проверяем только членство
      const memberCheck = db.prepare('SELECT user_id FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, req.userId);
      if (!memberCheck) {
        console.log(`[GET /api/groups/${groupId}] User is not a member of the group`);
        return res.status(403).json({ error: 'Not a member of this group' });
      }
      member = { role: 'member' }; // По умолчанию member для старых записей
    }
    
    if (!member) {
      console.log(`[GET /api/groups/${groupId}] Member not found`);
      return res.status(403).json({ error: 'Not a member of this group' });
    }
    
    // Получаем группу
    let group;
    try {
      group = db.prepare('SELECT id, name, avatar_path, background_path, created_by, created_at FROM groups WHERE id = ?').get(groupId);
    } catch (e) {
      try {
        group = db.prepare('SELECT id, name, avatar_path, created_by, created_at FROM groups WHERE id = ?').get(groupId);
      } catch (e2) {
        group = db.prepare('SELECT id, name, created_by, created_at FROM groups WHERE id = ?').get(groupId);
        if (group) group.avatar_path = null;
      }
      if (group) group.background_path = null;
    }
    
    if (!group) {
      console.log(`[GET /api/groups/${groupId}] Group not found in database`);
      return res.status(404).json({ error: 'Group not found' });
    }
    
    res.json({
      id: group.id,
      name: group.name,
      avatarPath: group.avatar_path || null,
      backgroundPath: group.background_path || null,
      createdBy: group.created_by,
      createdAt: group.created_at,
      userRole: member.role || 'member',
    });
  } catch (err) {
    console.error(`[GET /api/groups/${req.params.id}] Error:`, err);
    console.error('Error stack:', err.stack);
    res.status(500).json({ error: 'Internal server error: ' + err.message });
  }
});

// Создание группы
app.post('/api/groups', authMiddleware, (req, res) => {
  try {
  const { name, memberIds } = req.body || {};
    
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'Group name is required' });
    }
    
    if (!Array.isArray(memberIds)) {
      return res.status(400).json({ error: 'memberIds must be an array' });
    }
    
    const groupId = uuid();
    try {
      db.prepare('INSERT INTO groups (id, name, created_by, avatar_path) VALUES (?, ?, ?, ?)').run(groupId, name.trim(), req.userId, null);
    } catch (e) {
      // Если avatar_path не существует, создаём без него
      db.prepare('INSERT INTO groups (id, name, created_by) VALUES (?, ?, ?)').run(groupId, name.trim(), req.userId);
    }
    
    let addMember;
    try {
      addMember = db.prepare('INSERT INTO group_members (group_id, user_id, role) VALUES (?, ?, ?)');
    } catch (e) {
      // Если role не существует, создаём без него
      addMember = db.prepare('INSERT INTO group_members (group_id, user_id) VALUES (?, ?)');
    }
    const uniqueMemberIds = [...new Set([...memberIds, req.userId])];
    
    uniqueMemberIds.forEach(uid => {
      try {
        // Создатель группы становится администратором
        const role = uid === req.userId ? 'admin' : 'member';
        // Пробуем добавить с role, если не получится - без него
        try {
          addMember.run(groupId, uid, role);
        } catch (e) {
          // Если не получилось с role, пробуем без него
          db.prepare('INSERT INTO group_members (group_id, user_id) VALUES (?, ?)').run(groupId, uid);
        }
      } catch (e) {
        console.error(`Failed to add member ${uid}:`, e.message);
      }
    });
    
    uniqueMemberIds.forEach(uid => emitToUser(uid, 'sync', { type: 'groups' }));
    res.json({ id: groupId, name: name.trim() });
  } catch (err) {
    console.error('Create group error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Обновление группы
app.put('/api/groups/:id', authMiddleware, (req, res) => {
  try {
    const { name, backgroundPath } = req.body || {};
    
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(req.params.id, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can edit group' });
    }
    
    if (name !== undefined) {
      if (!name || typeof name !== 'string' || !name.trim()) {
        return res.status(400).json({ error: 'Group name is required' });
      }
      db.prepare('UPDATE groups SET name = ? WHERE id = ?').run(name.trim(), req.params.id);
    }
    
    if (backgroundPath !== undefined) {
      const val = backgroundPath === null || backgroundPath === '' ? null : String(backgroundPath);
      try {
        db.prepare('UPDATE groups SET background_path = ? WHERE id = ?').run(val, req.params.id);
      } catch (e) {
        // колонка может отсутствовать в старых БД
      }
    }
    
    let group;
    try {
      group = db.prepare('SELECT id, name, avatar_path, background_path, created_by, created_at FROM groups WHERE id = ?').get(req.params.id);
    } catch (e) {
      group = db.prepare('SELECT id, name, avatar_path, created_by, created_at FROM groups WHERE id = ?').get(req.params.id);
      if (group) group.background_path = null;
    }
    emitSyncGroupsToGroupMembers(req.params.id);
    res.json({
      id: group.id,
      name: group.name,
      avatarPath: group.avatar_path || null,
      backgroundPath: (group && group.background_path) || null,
      createdBy: group.created_by,
      createdAt: group.created_at,
    });
  } catch (err) {
    console.error('Update group error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Загрузка аватара группы
app.post('/api/groups/:id/avatar', authMiddleware, upload.single('avatar'), (req, res) => {
  try {
    // Проверяем, что пользователь является администратором группы
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(req.params.id, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can change group avatar' });
    }
    
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const avatarPath = '/uploads/' + req.file.filename;
    db.prepare('UPDATE groups SET avatar_path = ? WHERE id = ?').run(avatarPath, req.params.id);
    emitSyncGroupsToGroupMembers(req.params.id);
    res.json({ avatarPath });
  } catch (err) {
    console.error('Group avatar upload error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Загрузка фона группы (как в Telegram)
app.post('/api/groups/:id/background', authMiddleware, upload.single('background'), (req, res) => {
  try {
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(req.params.id, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can change group background' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    const backgroundPath = '/uploads/' + req.file.filename;
    try {
      db.prepare('UPDATE groups SET background_path = ? WHERE id = ?').run(backgroundPath, req.params.id);
    } catch (e) {
      return res.status(500).json({ error: 'Database update failed' });
    }
    dbSave();
    emitSyncGroupsToGroupMembers(req.params.id);
    res.json({ backgroundPath });
  } catch (err) {
    console.error('Group background upload error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Убрать фон группы
app.delete('/api/groups/:id/background', authMiddleware, (req, res) => {
  try {
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(req.params.id, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can change group background' });
    }
    try {
      db.prepare('UPDATE groups SET background_path = NULL WHERE id = ?').run(req.params.id);
    } catch (e) {
      return res.status(500).json({ error: 'Database update failed' });
    }
    dbSave();
    emitSyncGroupsToGroupMembers(req.params.id);
    res.json({ backgroundPath: null });
  } catch (err) {
    console.error('Group background clear error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Удаление группы (только администратор)
app.delete('/api/groups/:id', authMiddleware, (req, res) => {
  try {
    const groupId = req.params.id;
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can delete the group' });
    }
    const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
    db.prepare('DELETE FROM messages WHERE recipient_type = ? AND recipient_id = ?').run('group', groupId);
    db.prepare('DELETE FROM group_members WHERE group_id = ?').run(groupId);
    db.prepare('DELETE FROM groups WHERE id = ?').run(groupId);
    dbSave();
    members.forEach((m) => emitToUser(m.user_id, 'sync', { type: 'groups' }));
    res.json({ deleted: true });
  } catch (err) {
    console.error('Delete group error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение участников группы
app.get('/api/groups/:id/members', authMiddleware, (req, res) => {
  try {
    // Проверяем, что пользователь является участником группы
    let userMember;
    try {
      userMember = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(req.params.id, req.userId);
    } catch (e) {
      // Если поле role не существует, проверяем только членство
      const memberCheck = db.prepare('SELECT user_id FROM group_members WHERE group_id = ? AND user_id = ?').get(req.params.id, req.userId);
      if (!memberCheck) {
        return res.status(403).json({ error: 'Not a member of this group' });
      }
      userMember = { role: 'member' };
    }
    
    if (!userMember) {
      return res.status(403).json({ error: 'Not a member of this group' });
    }
    
    // Получаем участников, обрабатывая случай отсутствия поля role
    let rows;
    try {
      rows = db.prepare(`
        SELECT u.id, u.login, u.display_name, u.bio, u.avatar_path, gm.role 
        FROM group_members gm 
        JOIN users u ON u.id = gm.user_id 
        WHERE gm.group_id = ?
        ORDER BY 
          CASE WHEN gm.role = 'admin' THEN 1 ELSE 2 END,
          u.display_name
      `).all(req.params.id);
    } catch (e) {
      // Если поле role не существует, получаем без него
      rows = db.prepare(`
        SELECT u.id, u.login, u.display_name, u.bio, u.avatar_path, g.created_by
        FROM group_members gm 
        JOIN users u ON u.id = gm.user_id 
        JOIN groups g ON g.id = gm.group_id
        WHERE gm.group_id = ?
        ORDER BY u.display_name
      `).all(req.params.id);
      
      // Определяем роль: создатель группы = admin, остальные = member
      rows = rows.map(r => ({
        ...r,
        role: r.created_by === r.id ? 'admin' : 'member'
      }));
    }
    
    res.json(rows.map(u => ({
      id: u.id,
      login: u.login,
      displayName: u.display_name,
      bio: u.bio || '',
      avatarPath: u.avatar_path,
      role: u.role || 'member',
    })));
  } catch (err) {
    console.error('Get group members error:', err);
    res.status(500).json({ error: 'Internal server error: ' + err.message });
  }
});

// Добавление участников в группу
app.post('/api/groups/:id/members', authMiddleware, (req, res) => {
  try {
    const { userIds } = req.body || {};
    
    // Проверяем, что пользователь является администратором группы
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(req.params.id, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can add members' });
    }
    
    if (!Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ error: 'userIds must be a non-empty array' });
    }
    
    const addMember = db.prepare('INSERT OR IGNORE INTO group_members (group_id, user_id, role) VALUES (?, ?, ?)');
    const added = [];
    
    userIds.forEach(uid => {
      try {
        addMember.run(req.params.id, uid, 'member');
        added.push(uid);
      } catch (err) {
        console.error(`Failed to add member ${uid}:`, err);
      }
    });
    if (added.length) emitSyncGroupsToGroupMembers(req.params.id);
    res.json({ added });
  } catch (err) {
    console.error('Add group members error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Удаление участника из группы
app.delete('/api/groups/:id/members/:userId', authMiddleware, (req, res) => {
  try {
    const { id: groupId, userId } = req.params;
    
    // Проверяем права доступа
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, req.userId);
    if (!member) {
      return res.status(403).json({ error: 'Not a member of this group' });
    }
    
    // Администратор может удалять кого угодно, обычный участник может удалить только себя
    if (member.role !== 'admin' && userId !== req.userId) {
      return res.status(403).json({ error: 'You can only remove yourself from the group' });
    }
    
    // Нельзя удалить создателя группы
    const group = db.prepare('SELECT created_by FROM groups WHERE id = ?').get(groupId);
    if (group && group.created_by === userId) {
      return res.status(400).json({ error: 'Cannot remove group creator' });
    }
    
    db.prepare('DELETE FROM group_members WHERE group_id = ? AND user_id = ?').run(groupId, userId);
    emitSyncGroupsToGroupMembers(groupId);
    res.json({ success: true });
  } catch (err) {
    console.error('Remove group member error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Изменение роли участника
app.put('/api/groups/:id/members/:userId/role', authMiddleware, (req, res) => {
  try {
    const { id: groupId, userId } = req.params;
    const { role } = req.body || {};
    
    if (role !== 'admin' && role !== 'member') {
      return res.status(400).json({ error: 'Role must be "admin" or "member"' });
    }
    
    // Только администратор может изменять роли
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, req.userId);
    if (!member || member.role !== 'admin') {
      return res.status(403).json({ error: 'Only admins can change roles' });
    }
    
    // Нельзя изменить роль создателя группы
    const group = db.prepare('SELECT created_by FROM groups WHERE id = ?').get(groupId);
    if (group && group.created_by === userId && role !== 'admin') {
      return res.status(400).json({ error: 'Group creator must remain admin' });
    }
    
    db.prepare('UPDATE group_members SET role = ? WHERE group_id = ? AND user_id = ?').run(role, groupId, userId);
    emitSyncGroupsToGroupMembers(groupId);
    res.json({ success: true, role });
  } catch (err) {
    console.error('Change member role error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение сообщений
app.get('/api/messages', authMiddleware, (req, res) => {
  try {
  const { type, id } = req.query;

    if (!type || !id) {
      return res.status(400).json({ error: 'type and id are required' });
    }

  const recipientType = type === 'group' ? 'group' : 'user';
    let rows;
    if (recipientType === 'user') {
      // Личный чат: сообщения в обе стороны (я → другой и другой → я)
      rows = db.prepare(`
        SELECT m.id, m.sender_id, m.recipient_type, m.recipient_id, m.content, m.created_at, m.attachment_path,
               m.reply_to_id, m.edited_at, m.is_deleted, m.forward_from_id, m.forward_from_name,
               m.message_type, m.call_duration_sec
        FROM messages m
        WHERE m.recipient_type = 'user' AND (
          (m.sender_id = ? AND m.recipient_id = ?) OR (m.sender_id = ? AND m.recipient_id = ?)
        )
        ORDER BY m.created_at ASC
      `).all(req.userId, id, id, req.userId);
    } else {
      rows = db.prepare(`
        SELECT m.id, m.sender_id, m.recipient_type, m.recipient_id, m.content, m.created_at, m.attachment_path,
               m.reply_to_id, m.edited_at, m.is_deleted, m.forward_from_id, m.forward_from_name,
               m.message_type, m.call_duration_sec
        FROM messages m
        WHERE m.recipient_type = ? AND m.recipient_id = ?
        ORDER BY m.created_at ASC
      `).all(recipientType, id);
    }

    const getReplyTo = (replyToId) => {
      if (!replyToId) return null;
      const r = db.prepare('SELECT id, content, sender_id FROM messages WHERE id = ?').get(replyToId);
      if (!r) return null;
      const s = db.prepare('SELECT display_name FROM users WHERE id = ?').get(r.sender_id);
      return { id: r.id, content: r.content || '', senderName: s?.display_name || '' };
    };

    const messageIds = rows.map((row) => row.id);
    const reactionGroups = getReactionsGroupedByMessageIds(messageIds);

    const messages = rows.map(m => {
      const sender = db.prepare('SELECT display_name, avatar_path FROM users WHERE id = ?').get(m.sender_id);
      const replyTo = getReplyTo(m.reply_to_id);
      const rg = reactionGroups[m.id] || {};
      return {
        id: m.id,
        senderId: m.sender_id,
        senderName: sender?.display_name,
        senderAvatar: sender?.avatar_path,
        content: m.content,
        createdAt: m.created_at,
        attachmentPath: m.attachment_path || null,
        replyToId: m.reply_to_id || null,
        replyToContent: replyTo?.content ?? null,
        replyToSenderName: replyTo?.senderName ?? null,
        editedAt: m.edited_at || null,
        isDeleted: Number(m.is_deleted) === 1,
        forwardFromId: m.forward_from_id || null,
        forwardFromName: m.forward_from_name || null,
        messageType: m.message_type || null,
        callDurationSec: m.call_duration_sec != null ? m.call_duration_sec : null,
        reactions: toClientReactions(rg, req.userId),
      };
    });

    const pinned = getPinnedListForChat(recipientType, id);

    let peerLastReadAt = null;
    if (recipientType === 'user') {
      try {
        const rr = db.prepare('SELECT last_read_created_at FROM dm_read_receipts WHERE reader_id = ? AND peer_id = ?').get(id, req.userId);
        peerLastReadAt = rr?.last_read_created_at != null ? Number(rr.last_read_created_at) : null;
      } catch (e) {
        peerLastReadAt = null;
      }
    }

    res.json({ messages, pinned, peerLastReadAt: recipientType === 'user' ? peerLastReadAt : null });
  } catch (err) {
    console.error('Get messages error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/admin/settings', authMiddleware, adminMiddleware, (req, res) => {
  try {
    res.json({
      allowUsernameChangeAll: getAppSetting('allow_username_change_all', '1') === '1',
    });
  } catch (err) {
    console.error('Admin get settings:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/admin/settings', authMiddleware, adminMiddleware, (req, res) => {
  try {
    const { allowUsernameChangeAll } = req.body || {};
    if (typeof allowUsernameChangeAll !== 'boolean') {
      return res.status(400).json({ error: 'allowUsernameChangeAll (boolean) is required' });
    }
    setAppSetting('allow_username_change_all', allowUsernameChangeAll ? '1' : '0');
    res.json({ allowUsernameChangeAll });
  } catch (err) {
    console.error('Admin put settings:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Админ: временный бан пользователя
app.post('/api/admin/users/:id/ban', authMiddleware, adminMiddleware, (req, res) => {
  try {
    const targetId = req.params.id;
    const { durationSec } = req.body || {};
    if (!targetId) return res.status(400).json({ error: 'User id is required' });
    if (targetId === req.userId) return res.status(400).json({ error: 'Cannot ban yourself' });
    const nowSec = Math.floor(Date.now() / 1000);
    const banUntil = typeof durationSec === 'number' && durationSec > 0 ? nowSec + Math.floor(durationSec) : null;
    db.prepare('UPDATE users SET ban_until = ? WHERE id = ?').run(banUntil, targetId);
    res.json({ ok: true, banUntil });
  } catch (err) {
    console.error('Admin ban error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Админ: выдать / снять галочку верификации
app.post('/api/admin/users/:id/verify', authMiddleware, adminMiddleware, (req, res) => {
  try {
    const targetId = req.params.id;
    const { verified } = req.body || {};
    if (!targetId) return res.status(400).json({ error: 'User id is required' });
    const val = verified ? 1 : 0;
    db.prepare('UPDATE users SET is_verified = ? WHERE id = ?').run(val, targetId);
    res.json({ ok: true, isVerified: !!val });
  } catch (err) {
    console.error('Admin verify error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// WebSocket соединения
io.on('connection', (socket) => {
  let currentUserId = null;
  
  socket.on('auth', (token) => {
    if (token == null || typeof token !== 'string' || !token.trim()) {
      socket.emit('auth_fail');
      return;
    }
    try {
      const decoded = Buffer.from(token.trim(), 'base64').toString('utf8');
      const payload = JSON.parse(decoded);
      currentUserId = payload.userId;
      if (currentUserId) {
        if (!userSockets.has(currentUserId)) userSockets.set(currentUserId, new Set());
        userSockets.get(currentUserId).add(socket);
        // Обновляем время последнего захода при подключении
        try {
          db.prepare('UPDATE users SET last_seen_at = strftime(\'%s\', \'now\') WHERE id = ?').run(currentUserId);
        } catch (e) { /* ignore */ }
        socket.emit('auth_ok');
      } else {
        socket.emit('auth_fail');
      }
    } catch (err) {
      socket.emit('auth_fail');
    }
  });

  // Отправка сообщения (текст, голосовое, вложение файла, ответ, пересланное)
  socket.on('send_message', ({ recipientType, recipientId, content, voicePath, replyToId, forwardFromId, forwardFromName, forwardContent, forwardAttachmentPath, attachmentPath: attachmentPathPayload }) => {
    const isVoice = voicePath && typeof voicePath === 'string' && voicePath.trim().length > 0;
    const isForward = forwardContent !== undefined || (forwardAttachmentPath && forwardAttachmentPath.trim());
    const hasFileAttachment = attachmentPathPayload && typeof attachmentPathPayload === 'string' && attachmentPathPayload.trim().length > 0;
    const contentVal = isVoice ? '' : (content?.trim() ?? '');
    if (!currentUserId) return;
    if (!isVoice && !isForward && !contentVal && !hasFileAttachment) return;

    if (recipientType === 'user') {
      const blocked = db.prepare('SELECT 1 FROM blocks WHERE user_id = ? AND blocked_user_id = ?').get(recipientId, currentUserId);
      if (blocked) {
        socket.emit('send_message_error', { code: 'blocked', message: 'You are blocked by this user' });
        return;
      }
    }

    const replyToIdVal = replyToId && typeof replyToId === 'string' ? replyToId.trim() : null;
    const fwdId = forwardFromId && typeof forwardFromId === 'string' ? forwardFromId.trim() : null;
    const fwdName = forwardFromName && typeof forwardFromName === 'string' ? forwardFromName.trim() : null;
    const fwdContent = forwardContent != null ? String(forwardContent) : null;
    const fwdPath = forwardAttachmentPath && typeof forwardAttachmentPath === 'string' ? forwardAttachmentPath.trim() : null;
    const filePath = hasFileAttachment ? attachmentPathPayload.trim() : null;

    try {
      const msgId = uuid();
      const sender = db.prepare('SELECT display_name, avatar_path FROM users WHERE id = ?').get(currentUserId);
      const attachmentPath = isVoice ? voicePath.trim() : (fwdPath || filePath || null);

      db.prepare(`
        INSERT INTO messages (id, sender_id, recipient_type, recipient_id, content, attachment_path, reply_to_id, forward_from_id, forward_from_name)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(msgId, currentUserId, recipientType, recipientId, isForward ? (contentVal || fwdContent || '') : contentVal, attachmentPath, replyToIdVal || null, fwdId || null, fwdName || null);

      const getReplyTo = (rid) => {
        if (!rid) return null;
        const r = db.prepare('SELECT id, content, sender_id FROM messages WHERE id = ?').get(rid);
        if (!r) return null;
        const s = db.prepare('SELECT display_name FROM users WHERE id = ?').get(r.sender_id);
        return { content: r.content || '', senderName: s?.display_name || '' };
      };
      const replyTo = getReplyTo(replyToIdVal);

      const msg = {
        id: msgId,
        senderId: currentUserId,
        senderName: sender?.display_name,
        senderAvatar: sender?.avatar_path,
        content: isForward ? (contentVal || fwdContent || '') : contentVal,
        createdAt: Math.floor(Date.now() / 1000),
        attachmentPath,
        replyToId: replyToIdVal,
        replyToContent: replyTo?.content ?? null,
        replyToSenderName: replyTo?.senderName ?? null,
        editedAt: null,
        isDeleted: false,
        forwardFromId: fwdId,
        forwardFromName: fwdName,
        reactions: {},
      };

      const payload = { ...msg, recipientType, recipientId };
      if (recipientType === 'user') {
        emitToUser(recipientId, 'new_message', payload);
        emitToUser(currentUserId, 'new_message', payload);
      } else {
        const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(recipientId);
        members.forEach(member => emitToUser(member.user_id, 'new_message', payload));
      }
    } catch (err) {
      console.error('Send message error:', err);
    }
  });

  // Редактирование сообщения (только своё)
  socket.on('edit_message', ({ messageId, content }) => {
    if (!currentUserId || !messageId || content == null) return;
    const c = String(content).trim();
    try {
      const row = db.prepare('SELECT id, sender_id, recipient_type, recipient_id, attachment_path FROM messages WHERE id = ?').get(messageId);
      if (!row || row.sender_id !== currentUserId) return;
      if (row.attachment_path) return; // голосовые не редактируем
      const editedAt = Math.floor(Date.now() / 1000);
      db.prepare('UPDATE messages SET content = ?, edited_at = ? WHERE id = ?').run(c, editedAt, messageId);
      const payload = { messageId, content: c, editedAt, recipientType: row.recipient_type, recipientId: row.recipient_id };
      if (row.recipient_type === 'user') {
        emitToUser(row.recipient_id, 'message_updated', payload);
        emitToUser(currentUserId, 'message_updated', payload);
    } else {
        const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(row.recipient_id);
        members.forEach(member => emitToUser(member.user_id, 'message_updated', payload));
      }
    } catch (err) {
      console.error('Edit message error:', err);
    }
  });

  // Удаление сообщения (только своё, мягкое удаление)
  socket.on('delete_message', ({ messageId }) => {
    if (!currentUserId || !messageId) return;
    try {
      const row = db.prepare('SELECT id, sender_id, recipient_type, recipient_id FROM messages WHERE id = ?').get(messageId);
      if (!row || row.sender_id !== currentUserId) return;
      let hadPin = false;
      try {
        hadPin = !!db.prepare('SELECT 1 FROM pinned_messages WHERE message_id = ?').get(messageId);
        db.prepare('DELETE FROM message_reactions WHERE message_id = ?').run(messageId);
        db.prepare('DELETE FROM pinned_messages WHERE message_id = ?').run(messageId);
      } catch (e) { /* ignore */ }
      db.prepare('UPDATE messages SET is_deleted = 1, content = ? WHERE id = ?').run('', messageId);
      dbSave();
      setImmediate(() => dbSave());
      const check = db.prepare('SELECT is_deleted FROM messages WHERE id = ?').get(messageId);
      if (check && Number(check.is_deleted) !== 1) {
        console.error('[delete_message] UPDATE не применился для', messageId, check);
      }
      const payload = { messageId, recipientType: row.recipient_type, recipientId: String(row.recipient_id) };
      if (row.recipient_type === 'user') {
        emitToUser(row.recipient_id, 'message_deleted', payload);
        emitToUser(currentUserId, 'message_deleted', payload);
      } else {
        const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(row.recipient_id);
        members.forEach(member => emitToUser(member.user_id, 'message_deleted', payload));
      }
      if (hadPin) {
        try {
          const pinned = getPinnedListForChat(row.recipient_type, row.recipient_id);
          emitToChatParticipants(row.recipient_type, row.recipient_id, 'pins_updated', { recipientType: row.recipient_type, recipientId: String(row.recipient_id), pinned }, currentUserId);
        } catch (e) { /* ignore */ }
      }
    } catch (err) {
      console.error('Delete message error:', err);
    }
  });

  socket.on('mark_read', ({ peerId, lastReadCreatedAt }) => {
    if (!currentUserId || !peerId) return;
    const peer = String(peerId).trim();
    const t = typeof lastReadCreatedAt === 'number' && lastReadCreatedAt > 0 ? Math.floor(lastReadCreatedAt) : 0;
    if (!t || String(peer) === String(currentUserId)) return;
    if (!userCanAccessChat(currentUserId, 'user', peer)) return;
    try {
      const cur = db.prepare('SELECT last_read_created_at FROM dm_read_receipts WHERE reader_id = ? AND peer_id = ?').get(currentUserId, peer);
      const prev = cur?.last_read_created_at != null ? Number(cur.last_read_created_at) : 0;
      const next = Math.max(prev, t);
      db.prepare('INSERT OR REPLACE INTO dm_read_receipts (reader_id, peer_id, last_read_created_at) VALUES (?, ?, ?)').run(currentUserId, peer, next);
      dbSave();
      emitToUser(peer, 'peer_read_receipt', { readerId: currentUserId, lastReadCreatedAt: next });
    } catch (err) {
      console.error('mark_read error:', err);
    }
  });

  socket.on('toggle_reaction', ({ messageId, emoji, recipientType, recipientId }) => {
    if (!currentUserId || !messageId || emoji == null || !recipientType || recipientId == null) return;
    const rt = recipientType === 'group' ? 'group' : 'user';
    const rid = String(recipientId).trim();
    if (!rid || !userCanAccessChat(currentUserId, rt, rid)) return;
    const e = String(emoji).trim();
    if (!e || [...e].length > 16) return;
    const row = db.prepare('SELECT id, sender_id, recipient_type, recipient_id FROM messages WHERE id = ?').get(messageId);
    if (!row || !messageBelongsToChat(row, rt, rid, currentUserId)) return;
    const existing = db.prepare('SELECT 1 FROM message_reactions WHERE message_id = ? AND user_id = ? AND emoji = ?').get(messageId, currentUserId, e);
    if (existing) {
      db.prepare('DELETE FROM message_reactions WHERE message_id = ? AND user_id = ? AND emoji = ?').run(messageId, currentUserId, e);
    } else {
      db.prepare('INSERT INTO message_reactions (message_id, user_id, emoji) VALUES (?, ?, ?)').run(messageId, currentUserId, e);
    }
    dbSave();
    const grouped = getReactionsGroupedByMessageIds([messageId])[messageId] || {};
    emitToChatParticipants(rt, rid, 'reaction_updated', { messageId, recipientType: rt, recipientId: rid, reactions: grouped }, currentUserId);
  });

  socket.on('typing', ({ recipientType, recipientId, active }) => {
    if (!currentUserId) return;
    const rt = recipientType === 'group' ? 'group' : 'user';
    const rid = recipientId != null ? String(recipientId).trim() : '';
    if (!rid || !userCanAccessChat(currentUserId, rt, rid)) return;
    const sender = db.prepare('SELECT display_name FROM users WHERE id = ?').get(currentUserId);
    const payload = { userId: currentUserId, displayName: sender?.display_name || '', recipientType: rt, recipientId: rid, active: !!active };
    if (rt === 'user') {
      emitToUser(rid, 'peer_typing', payload);
    } else {
      try {
        const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(rid);
        members.forEach((m) => {
          if (m.user_id !== currentUserId) emitToUser(m.user_id, 'peer_typing', payload);
        });
      } catch (e) { /* ignore */ }
    }
  });

  socket.on('pin_message', ({ messageId, recipientType, recipientId }) => {
    if (!currentUserId || !messageId || !recipientType || recipientId == null) return;
    const rt = recipientType === 'group' ? 'group' : 'user';
    const rid = String(recipientId).trim();
    if (!canPinInChat(currentUserId, rt, rid)) {
      socket.emit('pin_error', { message: 'Недостаточно прав для закрепления' });
      return;
    }
    if (!userCanAccessChat(currentUserId, rt, rid)) return;
    const row = db.prepare('SELECT id, sender_id, recipient_type, recipient_id FROM messages WHERE id = ?').get(messageId);
    if (!row || !messageBelongsToChat(row, rt, rid, currentUserId)) return;
    const n = db.prepare('SELECT COUNT(*) as c FROM pinned_messages WHERE recipient_type = ? AND recipient_id = ?').get(rt, rid);
    if (n && Number(n.c) >= MAX_PINS_PER_CHAT) {
      socket.emit('pin_error', { message: `Максимум ${MAX_PINS_PER_CHAT} закреплённых сообщений` });
      return;
    }
    try {
      db.prepare('INSERT INTO pinned_messages (message_id, recipient_type, recipient_id, pinned_by) VALUES (?, ?, ?, ?)').run(messageId, rt, rid, currentUserId);
      dbSave();
    } catch (err) {
      if (err && String(err.message || '').includes('UNIQUE')) return;
      console.error('pin_message', err);
      return;
    }
    const pinned = getPinnedListForChat(rt, rid);
    emitToChatParticipants(rt, rid, 'pins_updated', { recipientType: rt, recipientId: rid, pinned }, currentUserId);
  });

  socket.on('unpin_message', ({ messageId, recipientType, recipientId }) => {
    if (!currentUserId || !messageId || !recipientType || recipientId == null) return;
    const rt = recipientType === 'group' ? 'group' : 'user';
    const rid = String(recipientId).trim();
    if (!canPinInChat(currentUserId, rt, rid)) {
      socket.emit('pin_error', { message: 'Недостаточно прав' });
      return;
    }
    if (!userCanAccessChat(currentUserId, rt, rid)) return;
    const pin = db.prepare('SELECT message_id FROM pinned_messages WHERE message_id = ? AND recipient_type = ? AND recipient_id = ?').get(messageId, rt, rid);
    if (!pin) return;
    db.prepare('DELETE FROM pinned_messages WHERE message_id = ?').run(messageId);
    dbSave();
    const pinned = getPinnedListForChat(rt, rid);
    emitToChatParticipants(rt, rid, 'pins_updated', { recipientType: rt, recipientId: rid, pinned }, currentUserId);
  });

  // WebRTC сигналинг для звонков (работают только после auth)
  socket.on('call:offer', ({ to, offer, isGroup, groupId }) => {
    if (!currentUserId) return;
    const hasOffer = offer && typeof offer === 'object' && offer.type && typeof offer.sdp === 'string';
    if (!hasOffer) return;
    let targets = [];
    if (isGroup && groupId) {
      activeGroupCalls.set(groupId, currentUserId);
      const rows = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
      targets = rows.map(r => r.user_id).filter(uid => uid !== currentUserId);
      targets.forEach(uid => {
        emitToUser(uid, 'call:group_call_started', { groupId });
      });
    } else if (!isGroup && to) {
      targets = [to];
    }
    targets.forEach(uid => {
      emitToUser(uid, 'call:incoming', { from: currentUserId, offer, isGroup: !!isGroup, groupId: groupId || null });
    });
    // Другие вкладки/устройства звонящего: показать, что исходящий уже начат (не дублировать звонок)
    if (isGroup && groupId) {
      emitToUserExcept(currentUserId, socket, 'call:outgoing_started', { isGroup: true, groupId });
    } else if (!isGroup && to) {
      emitToUserExcept(currentUserId, socket, 'call:outgoing_started', { isGroup: false, peerId: to });
    }
  });

  socket.on('call:answer', ({ to, groupId, answer }) => {
    if (!currentUserId || !answer) return;
    if (groupId) {
      // Для групповых звонков отправляем answer всем участникам группы
      const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
      members.forEach((m) => {
        if (m.user_id !== currentUserId) {
          emitToUser(m.user_id, 'call:answer', { from: currentUserId, answer, groupId });
        }
      });
      // Остальные устройства отвечающего: убрать входящий звонок
      emitToUserExcept(currentUserId, socket, 'call:inbound_dismiss', { from: null, groupId });
    } else if (to) {
      // Для одиночных звонков отправляем конкретному пользователю
      emitToUser(to, 'call:answer', { from: currentUserId, answer });
      emitToUserExcept(currentUserId, socket, 'call:inbound_dismiss', { from: to, groupId: null });
      // Остальные устройства звонящего: снять баннер «исходящий на другом устройстве»
      emitToUserExcept(to, null, 'call:outgoing_ended', { peerId: currentUserId, groupId: null });
    }
  });

  /** Отклонение входящего (ЛС или группа) — уведомить звонящего и снять звонок на других своих устройствах */
  socket.on('call:reject_incoming', ({ to, groupId }) => {
    if (!currentUserId) return;
    if (groupId) {
      // Только свои другие устройства: отказ участника не рвёт групповой звонок для остальных
      emitToUserExcept(currentUserId, socket, 'call:inbound_dismiss', { from: null, groupId });
    } else if (to) {
      emitToUser(to, 'call:hangup', { from: currentUserId });
      emitToUserExcept(currentUserId, socket, 'call:inbound_dismiss', { from: to, groupId: null });
      emitToUserExcept(to, null, 'call:outgoing_ended', { peerId: currentUserId, groupId: null });
    }
  });

  socket.on('call:ice', ({ to, groupId, candidate }) => {
    if (!currentUserId || !candidate) return;
    if (groupId) {
      // Для групповых звонков отправляем ICE кандидаты всем участникам группы
      const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
      members.forEach((m) => {
        if (m.user_id !== currentUserId) {
          emitToUser(m.user_id, 'call:ice', { from: currentUserId, candidate, groupId });
        }
      });
    } else if (to) {
      // Для одиночных звонков отправляем конкретному пользователю
      emitToUser(to, 'call:ice', { from: currentUserId, candidate });
    }
  });

  socket.on('call:hangup', ({ to, groupId }) => {
    if (!currentUserId) return;
    if (groupId) {
      const isStarter = activeGroupCalls.get(groupId) === currentUserId;
      if (isStarter) {
        activeGroupCalls.delete(groupId);
        const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
        members.forEach(({ user_id }) => {
          emitToUser(user_id, 'call:group_call_ended', { groupId });
        });
      }
      const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
      members.forEach(({ user_id }) => {
        if (user_id !== currentUserId) emitToUser(user_id, 'call:hangup', { from: currentUserId });
      });
    }
    if (to) {
      emitToUser(to, 'call:hangup', { from: currentUserId });
      // Другие вкладки звонящего: сбросить «исходящий» при отмене до ответа
      emitToUserExcept(currentUserId, socket, 'call:outgoing_ended', { peerId: to, groupId: null });
    }
  });

  socket.on('call:end_for_all', ({ groupId }) => {
    if (!currentUserId || !groupId) return;
    // Проверяем, что пользователь является администратором группы
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, currentUserId);
    if (!member || member.role !== 'admin') return;
    // Завершаем звонок для всех участников
    activeGroupCalls.delete(groupId);
    const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
    members.forEach(({ user_id }) => {
      emitToUser(user_id, 'call:group_call_ended', { groupId });
      emitToUser(user_id, 'call:hangup', { from: currentUserId, endForAll: true });
    });
  });

  socket.on('call:renegotiate', ({ to, groupId, offer }) => {
    if (!currentUserId || !offer) return;
    if (groupId) {
      // Для групповых звонков отправляем всем участникам группы
      const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
      members.forEach((m) => {
        if (m.user_id !== currentUserId) {
          emitToUser(m.user_id, 'call:renegotiate', { from: currentUserId, offer, groupId });
        }
      });
    } else if (to) {
      // Для одиночных звонков отправляем конкретному пользователю
      emitToUser(to, 'call:renegotiate', { from: currentUserId, offer });
    }
  });

  socket.on('call:renegotiate-answer', ({ to, groupId, answer }) => {
    if (!currentUserId || !answer) return;
    if (groupId) {
      // Для групповых звонков отправляем ответ всем участникам группы
      const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId);
      members.forEach((m) => {
        if (m.user_id !== currentUserId) {
          emitToUser(m.user_id, 'call:renegotiate-answer', { from: currentUserId, answer, groupId });
        }
      });
    } else if (to) {
      // Для одиночных звонков отправляем конкретному пользователю
      emitToUser(to, 'call:renegotiate-answer', { from: currentUserId, answer });
    }
  });

  socket.on('call:mute_participant', ({ to, groupId }) => {
    if (!currentUserId || !to) return;
    if (!groupId) return;
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, currentUserId);
    if (!member || member.role !== 'admin') return;
    emitToUser(to, 'call:you_are_muted');
  });

  socket.on('call:unmute_participant', ({ to, groupId }) => {
    if (!currentUserId || !to) return;
    if (!groupId) return;
    const member = db.prepare('SELECT role FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, currentUserId);
    if (!member || member.role !== 'admin') return;
    emitToUser(to, 'call:you_are_unmuted');
  });

  socket.on('call:get_active_group_calls', () => {
    if (!currentUserId) return;
    const myGroups = db.prepare('SELECT group_id FROM group_members WHERE user_id = ?').all(currentUserId).map(r => r.group_id);
    const groupIds = myGroups.filter(gid => activeGroupCalls.has(gid));
    socket.emit('call:active_group_calls', { groupIds });
  });

  socket.on('call_ended', ({ recipientType, recipientId, durationSec }) => {
    if (!currentUserId) return;
    const type = recipientType === 'group' ? 'group' : 'user';
    const id = recipientId && typeof recipientId === 'string' ? recipientId.trim() : null;
    if (!id) return;
    const duration = typeof durationSec === 'number' && durationSec >= 0 ? Math.floor(durationSec) : 0;
    try {
      const msgId = uuid();
      const sender = db.prepare('SELECT display_name, avatar_path FROM users WHERE id = ?').get(currentUserId);
      db.prepare(`
        INSERT INTO messages (id, sender_id, recipient_type, recipient_id, content, message_type, call_duration_sec)
        VALUES (?, ?, ?, ?, '', 'call_ended', ?)
      `).run(msgId, currentUserId, type, id, duration);
      const msg = {
        id: msgId,
        senderId: currentUserId,
        senderName: sender?.display_name,
        senderAvatar: sender?.avatar_path,
        content: '',
        createdAt: Math.floor(Date.now() / 1000),
        attachmentPath: null,
        replyToId: null,
        replyToContent: null,
        replyToSenderName: null,
        editedAt: null,
        isDeleted: false,
        forwardFromId: null,
        forwardFromName: null,
        messageType: 'call_ended',
        callDurationSec: duration,
        reactions: {},
      };
      if (type === 'user') {
        // Чтобы оба участника чата добавили сообщение: у каждого в чате recipientId = "другой"
        emitToUser(currentUserId, 'new_message', { ...msg, recipientType: type, recipientId: id });
        emitToUser(id, 'new_message', { ...msg, recipientType: type, recipientId: currentUserId });
      } else {
        const payload = { ...msg, recipientType: type, recipientId: id };
        const members = db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(id);
        members.forEach((m) => emitToUser(m.user_id, 'new_message', payload));
      }
    } catch (err) {
      console.error('call_ended error:', err);
    }
  });

  socket.on('disconnect', () => {
    if (currentUserId) {
      try {
        db.prepare('UPDATE users SET last_seen_at = strftime(\'%s\', \'now\') WHERE id = ?').run(currentUserId);
      } catch (e) { /* ignore */ }
      const set = userSockets.get(currentUserId);
      if (set) {
        set.delete(socket);
        if (set.size === 0) userSockets.delete(currentUserId);
      }
    }
  });
});

// CORS preflight для DELETE (браузер может слать OPTIONS перед DELETE)
app.options('/api/groups/:id', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.sendStatus(204);
});

// Обработка 404 для API маршрутов (любой /api/... не совпавший с маршрутами выше)
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`[404] ${req.method} ${req.originalUrl} - Route not found`);
    return res.status(404).json({ error: 'API route not found', path: req.path });
  }
  next();
});

// Раздача веб-клиента (React/Vite) прямо Node-сервером.
// Это упрощает хостинг на VPS без nginx: достаточно положить client/dist рядом с server/.
const webDistDir = join(__dirname, '..', 'client', 'dist');
const webIndexHtml = join(webDistDir, 'index.html');
if (fs.existsSync(webIndexHtml)) {
  app.use(express.static(webDistDir));
  app.get('*', (req, res, next) => {
    // Не трогаем сокеты и загрузки.
    if (
      req.path.startsWith('/api') ||
      req.path.startsWith('/socket.io') ||
      req.path.startsWith('/uploads')
    ) {
      return next();
    }
    return res.sendFile(webIndexHtml);
  });
}

// Глобальный обработчик ошибок — всегда JSON с телом
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  console.error('[SERVER] Unhandled error:', err && err.message, err && err.stack);
  try {
    res.status(500).json({ error: 'Server error: ' + (err && err.message ? err.message : 'Unknown') });
  } catch (e) {
    res.status(500).end('Server error');
  }
});

const PORT = process.env.PORT || 3001;

function startServer(port) {
  return new Promise((resolve, reject) => {
    // Слушаем на всех интерфейсах (0.0.0.0) для доступа с мобильных устройств
    const domain = process.env.DOMAIN || 'localhost';
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
    httpServer.listen(port, '0.0.0.0', () => {
      console.log(`Server running on http://localhost:${port}`);
      console.log(`Server accessible from network at http://${domain}:${port}`);
      if (process.env.NODE_ENV === 'production') {
        console.log(`Production mode: API available at ${protocol}://${domain}`);
      }
      console.log('Registered routes:');
      console.log('  GET  /api/test');
      console.log('  GET  /api/version');
      console.log('  GET  /api/health');
      console.log('  POST /api/auth/login');
      console.log('  GET  /api/users');
      console.log('  GET  /api/users/me');
      console.log('  PUT  /api/users/me');
      console.log('  POST /api/users/avatar');
      console.log('  POST /api/voice/upload');
      console.log('  GET  /api/groups');
      console.log('  GET  /api/groups/:id');
      console.log('  POST /api/groups');
      console.log('  PUT  /api/groups/:id');
      console.log('  POST /api/groups/:id/avatar');
      console.log('  GET  /api/groups/:id/members');
      console.log('  POST /api/groups/:id/members');
      console.log('  DELETE /api/groups/:id/members/:userId');
      console.log('  PUT  /api/groups/:id/members/:userId/role');
      resolve(port);
    }).on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.warn(`Port ${port} is already in use. Trying port ${port + 1}...`);
        reject(err);
      } else {
        console.error(`Failed to start server:`, err);
        reject(err);
      }
    });
  });
}

// Пытаемся запустить на порту 3001, если занят - пробуем 3002
startServer(PORT).catch(() => {
  startServer(3002).catch(() => {
    console.error('Failed to start server on ports 3001 and 3002');
    process.exit(1);
  });
});
