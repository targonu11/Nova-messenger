import initSqlJs from 'sql.js';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dbPath = join(__dirname, 'messenger.db');

let SQL = null;
let dbInstance = null;

export function save() {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (e) {
    console.error('DB save error:', e.message);
  }
}

function prepare(sql) {
  return {
    run(...params) {
      const stmt = dbInstance.prepare(sql);
      const arr = params.length ? Array.from(params) : [];
      if (arr.length) stmt.bind(arr);
      stmt.step();
      stmt.free();
      save();
    },
    get(...params) {
      const stmt = dbInstance.prepare(sql);
      stmt.bind(params);
      const row = stmt.step() ? stmt.getAsObject() : null;
      stmt.free();
      return row;
    },
    all(...params) {
      const stmt = dbInstance.prepare(sql);
      stmt.bind(params);
      const rows = [];
      while (stmt.step()) rows.push(stmt.getAsObject());
      stmt.free();
      return rows;
    },
  };
}

export const db = {
  prepare(sql) {
    if (!dbInstance) throw new Error('DB not loaded');
    return prepare(sql);
  },
  exec(sql) {
    if (!dbInstance) throw new Error('DB not loaded');
    dbInstance.exec(sql);
    save();
  },
};

export async function initDb() {
  if (SQL === null) SQL = await initSqlJs();
  
  // Закрываем старую базу если она открыта
  if (dbInstance) {
    try {
      dbInstance.close();
      dbInstance = null;
    } catch (e) {
      console.warn('Error closing old database:', e.message);
    }
  }
  
  // Загружаем существующую базу или создаём новую
  let data = null;
  if (fs.existsSync(dbPath)) {
    data = new Uint8Array(fs.readFileSync(dbPath));
  }
  dbInstance = new SQL.Database(data);
  dbInstance.run('PRAGMA journal_mode = WAL');
  
  // Создаём таблицы если их нет
  dbInstance.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      login TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      display_name TEXT NOT NULL,
      bio TEXT,
      avatar_path TEXT,
      phone TEXT UNIQUE,
      phone_verified INTEGER DEFAULT 0,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );
    CREATE TABLE IF NOT EXISTS phone_verification_codes (
      phone TEXT PRIMARY KEY,
      code TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      attempts INTEGER DEFAULT 0,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );
    CREATE TABLE IF NOT EXISTS groups (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      avatar_path TEXT,
      created_by TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now')),
      FOREIGN KEY (created_by) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS group_members (
      group_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      role TEXT DEFAULT 'member',
      joined_at INTEGER DEFAULT (strftime('%s','now')),
      PRIMARY KEY (group_id, user_id),
      FOREIGN KEY (group_id) REFERENCES groups(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      sender_id TEXT NOT NULL,
      recipient_type TEXT NOT NULL,
      recipient_id TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now')),
      FOREIGN KEY (sender_id) REFERENCES users(id)
    );
    CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_type, recipient_id);
    CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at);
    CREATE TABLE IF NOT EXISTS blocks (
      user_id TEXT NOT NULL,
      blocked_user_id TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now')),
      PRIMARY KEY (user_id, blocked_user_id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (blocked_user_id) REFERENCES users(id)
    );
    CREATE INDEX IF NOT EXISTS idx_blocks_user ON blocks(user_id);
  `);
  
  // Миграция: добавляем поля phone и phone_verified в таблицу users если их нет
  try {
    dbInstance.exec(`
      ALTER TABLE users ADD COLUMN phone TEXT;
      ALTER TABLE users ADD COLUMN phone_verified INTEGER DEFAULT 0;
    `);
  } catch (err) {
    // Поля уже существуют или другая ошибка - игнорируем
  }
  
  // Обновляем схему существующих таблиц (миграции)
  try {
    // Проверяем наличие полей в users
    const usersInfo = dbInstance.exec("PRAGMA table_info(users)");
    const userCols = usersInfo[0]?.values?.map(row => row[1]) || [];
    if (!userCols.includes('bio')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN bio TEXT');
      console.log('Added bio column to users table');
    }
    if (!userCols.includes('last_seen_at')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN last_seen_at INTEGER');
      console.log('Added last_seen_at column to users table');
    }
    if (!userCols.includes('hide_last_seen')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN hide_last_seen INTEGER DEFAULT 0');
      console.log('Added hide_last_seen column to users table');
    }
    if (!userCols.includes('is_verified')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN is_verified INTEGER DEFAULT 0');
      console.log('Added is_verified column to users table (migration)');
    }
    if (!userCols.includes('ban_until')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN ban_until INTEGER');
      console.log('Added ban_until column to users table (migration)');
    }
    if (!userCols.includes('e2e_public_key')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN e2e_public_key TEXT');
      console.log('Added e2e_public_key column to users table');
    }
    // Верификация и баны
    if (!userCols.includes('is_verified')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN is_verified INTEGER DEFAULT 0');
      console.log('Added is_verified column to users table');
    }
    if (!userCols.includes('ban_until')) {
      dbInstance.exec('ALTER TABLE users ADD COLUMN ban_until INTEGER');
      console.log('Added ban_until column to users table');
    }
    
    // Проверяем наличие поля avatar_path в groups
    const groupsInfo = dbInstance.exec("PRAGMA table_info(groups)");
    const hasGroupAvatar = groupsInfo[0]?.values?.some(row => row[1] === 'avatar_path');
    if (!hasGroupAvatar) {
      dbInstance.exec('ALTER TABLE groups ADD COLUMN avatar_path TEXT');
      console.log('Added avatar_path column to groups table');
    }
    
    // Проверяем наличие поля attachment_path в messages
    const messagesInfo = dbInstance.exec("PRAGMA table_info(messages)");
    const msgCols = messagesInfo[0]?.values?.map(row => row[1]) || [];
    if (!msgCols.includes('attachment_path')) {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN attachment_path TEXT');
      console.log('Added attachment_path column to messages table');
    }
    if (!msgCols.includes('reply_to_id')) {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN reply_to_id TEXT');
      console.log('Added reply_to_id column to messages table');
    }
    if (!msgCols.includes('edited_at')) {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN edited_at INTEGER');
      console.log('Added edited_at column to messages table');
    }
    try {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN is_deleted INTEGER DEFAULT 0');
      console.log('Added is_deleted column to messages table');
    } catch (e) {
      if (!e.message || !e.message.includes('duplicate column')) console.warn('is_deleted migration:', e.message);
    }
    if (!msgCols.includes('forward_from_id')) {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN forward_from_id TEXT');
      console.log('Added forward_from_id column to messages table');
    }
    if (!msgCols.includes('forward_from_name')) {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN forward_from_name TEXT');
      console.log('Added forward_from_name column to messages table');
    }
    if (!msgCols.includes('message_type')) {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN message_type TEXT');
      console.log('Added message_type column to messages table');
    }
    if (!msgCols.includes('call_duration_sec')) {
      dbInstance.exec('ALTER TABLE messages ADD COLUMN call_duration_sec INTEGER');
      console.log('Added call_duration_sec column to messages table');
    }

    // Проверяем наличие поля role в group_members
    const membersInfo = dbInstance.exec("PRAGMA table_info(group_members)");
    const hasRole = membersInfo[0]?.values?.some(row => row[1] === 'role');
    if (!hasRole) {
      dbInstance.exec('ALTER TABLE group_members ADD COLUMN role TEXT DEFAULT \'member\'');
      // Обновляем существующие записи: создатель группы = admin
      dbInstance.exec(`
        UPDATE group_members 
        SET role = 'admin' 
        WHERE EXISTS (
          SELECT 1 FROM groups g 
          WHERE g.id = group_members.group_id 
          AND g.created_by = group_members.user_id
        )
      `);
      console.log('Added role column to group_members table');
    }
  } catch (e) {
    console.warn('Schema migration warning:', e.message);
  }

  try {
    dbInstance.exec(`
      CREATE TABLE IF NOT EXISTS message_reactions (
        message_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        emoji TEXT NOT NULL,
        created_at INTEGER DEFAULT (strftime('%s','now')),
        PRIMARY KEY (message_id, user_id, emoji)
      );
      CREATE INDEX IF NOT EXISTS idx_reactions_message ON message_reactions(message_id);
      CREATE TABLE IF NOT EXISTS pinned_messages (
        message_id TEXT PRIMARY KEY,
        recipient_type TEXT NOT NULL,
        recipient_id TEXT NOT NULL,
        pinned_by TEXT NOT NULL,
        pinned_at INTEGER DEFAULT (strftime('%s','now'))
      );
      CREATE INDEX IF NOT EXISTS idx_pins_recipient ON pinned_messages(recipient_type, recipient_id);
      CREATE TABLE IF NOT EXISTS dm_read_receipts (
        reader_id TEXT NOT NULL,
        peer_id TEXT NOT NULL,
        last_read_created_at INTEGER NOT NULL,
        PRIMARY KEY (reader_id, peer_id)
      );
      CREATE TABLE IF NOT EXISTS servers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        icon_path TEXT,
        created_by TEXT NOT NULL,
        created_at INTEGER DEFAULT (strftime('%s','now')),
        FOREIGN KEY (created_by) REFERENCES users(id)
      );
      CREATE TABLE IF NOT EXISTS server_members (
        server_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        role TEXT DEFAULT 'member',
        joined_at INTEGER DEFAULT (strftime('%s','now')),
        PRIMARY KEY (server_id, user_id),
        FOREIGN KEY (server_id) REFERENCES servers(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
      );
      CREATE INDEX IF NOT EXISTS idx_server_members_user ON server_members(user_id);
    `);
  } catch (e) {
    console.warn('message_reactions/pinned_messages:', e.message);
  }

  try {
    const gInfo = dbInstance.exec('PRAGMA table_info(groups)');
    const gCols = gInfo[0]?.values?.map((row) => row[1]) || [];
    if (!gCols.includes('server_id')) {
      dbInstance.exec('ALTER TABLE groups ADD COLUMN server_id TEXT');
      console.log('Added server_id to groups');
    }
  } catch (e) {
    console.warn('groups server_id migration:', e.message);
  }

  try {
    dbInstance.exec(`
      CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY NOT NULL,
        value TEXT NOT NULL
      );
    `);
    const hasAllow = db.prepare('SELECT value FROM app_settings WHERE key = ?').get('allow_username_change_all');
    if (!hasAllow) {
      db.prepare('INSERT INTO app_settings (key, value) VALUES (?, ?)').run('allow_username_change_all', '1');
    }
  } catch (e) {
    console.warn('app_settings migration:', e.message);
  }

  save();
  console.log('Database initialized.');
}

/** Чтение серверной настройки (после initDb). */
export function getAppSetting(key, defaultVal = '') {
  try {
    const row = db.prepare('SELECT value FROM app_settings WHERE key = ?').get(key);
    if (row && row.value != null && row.value !== '') return String(row.value);
  } catch (e) {
    console.warn('getAppSetting:', e.message);
  }
  return defaultVal;
}

export function setAppSetting(key, value) {
  db.prepare('INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)').run(key, String(value));
}

export function closeDb() {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}

// Генерация случайного пароля
function generatePassword() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < 12; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

// Список юзернеймов и имён для сидирования (+55 дополнительных аккаунтов)
const ACCOUNTS_BASE = [
  { login: 'lololowkid', name: 'lololowkid' },
  { login: 'After_981', name: 'After_981' },
  { login: 'Bandl1k', name: 'Bandl1k' },
  { login: 'Shadow_2024', name: 'Shadow_2024' },
  { login: 'NeonX7', name: 'NeonX7' },
  { login: 'CyberWolf', name: 'CyberWolf' },
  { login: 'DarkPhoenix', name: 'DarkPhoenix' },
  { login: 'StormRider', name: 'StormRider' },
  { login: 'NightHawk', name: 'NightHawk' },
  { login: 'Quantum99', name: 'Quantum99' },
  { login: 'StarLight', name: 'StarLight' },
  { login: 'MysticX', name: 'MysticX' },
  { login: 'ThunderBolt', name: 'ThunderBolt' },
  { login: 'FireStorm', name: 'FireStorm' },
  { login: 'IceBreaker', name: 'IceBreaker' },
  { login: 'SkyWalker', name: 'SkyWalker' },
  { login: 'DragonSlayer', name: 'DragonSlayer' },
  { login: 'BladeRunner', name: 'BladeRunner' },
  { login: 'GhostRider', name: 'GhostRider' },
  { login: 'NovaStar', name: 'NovaStar' },
];

const ACCOUNTS_EXTRA = Array.from({ length: 55 }, (_, i) => {
  const n = String(i + 1).padStart(3, '0');
  const login = `nova_user_${n}`;
  return { login, name: `Nova User ${n}` };
});

const ACCOUNTS = [...ACCOUNTS_BASE, ...ACCOUNTS_EXTRA];

// Создание аккаунтов с случайными паролями
export async function seedUsers() {
  const { v4: uuid } = await import('uuid');
  
  // Не удаляем пользователей — только добавляем недостающие (группы и участники сохраняются)
  const insert = db.prepare('INSERT INTO users (id, login, password, display_name) VALUES (?, ?, ?, ?)');
  const credentials = [];
  
  console.log('Seeding accounts (only adding missing, keeping existing users and groups)...');
  
  for (const account of ACCOUNTS) {
    const existing = db.prepare('SELECT id, login, password FROM users WHERE login = ?').get(account.login);
    if (existing) {
      // Для уже существующего главного аккаунта ставим верификацию
      if (account.login === 'lololowkid') {
        try {
          db.prepare('UPDATE users SET is_verified = 1 WHERE id = ?').run(existing.id);
        } catch (e) {
          console.warn('Failed to set is_verified for existing lololowkid:', e.message);
        }
      }
      credentials.push({ login: account.login, password: '(existing)' });
      continue;
    }
    const password = generatePassword();
    const userId = uuid();
    try {
      insert.run(userId, account.login, password, account.name);
      if (account.login === 'lololowkid') {
        try {
          db.prepare('UPDATE users SET is_verified = 1 WHERE id = ?').run(userId);
        } catch (e) {
          console.warn('Failed to set is_verified for new lololowkid:', e.message);
        }
      }
      credentials.push({ login: account.login, password });
      console.log(`Created account: ${account.login}`);
    } catch (err) {
      console.error(`Failed to create account ${account.login}:`, err.message);
    }
  }
  
  const finalCount = db.prepare('SELECT COUNT(*) as c FROM users').get();
  console.log(`Total users: ${finalCount?.c || 0}`);
  
  // Для файла — все 20 аккаунтов с паролями из БД (у существующих пароль уже есть в БД)
  const allForFile = [];
  for (const acc of ACCOUNTS) {
    const row = db.prepare('SELECT id, login, password, display_name FROM users WHERE login = ?').get(acc.login);
    if (row) {
      allForFile.push({ login: row.login, password: row.password || '(n/a)', name: row.display_name });
    }
  }
  
  console.log('\n=== Account Credentials ===');
  credentials.forEach(({ login, password }) => console.log(`${login}: ${password}`));
  console.log('===========================\n');
  
  try {
    const accountsFilePath = join(__dirname, '..', 'accounts.txt');
    let content = '=== Все аккаунты и пароли ===\n\n';
    allForFile.forEach((u, index) => {
      content += `${index + 1}. Юзернейм: ${u.login}\n   Пароль: ${u.password}\n   Имя: ${u.name}\n\n`;
    });
    content += `==============================\nВсего записей: ${allForFile.length} (базовые + nova_user_001…)\n`;
    content += `Дата обновления: ${new Date().toLocaleString('ru-RU')}\n`;
    fs.writeFileSync(accountsFilePath, content, 'utf-8');
    console.log('✅ Список аккаунтов сохранен в файл: accounts.txt');
  } catch (err) {
    console.warn('Не удалось сохранить файл accounts.txt:', err.message);
  }
  
  return credentials;
}

// Поиск пользователя по логину
export function getUserByLogin(login) {
  return db.prepare('SELECT id, login, display_name, bio, avatar_path FROM users WHERE login = ?').get(login);
}

// Проверка логина и пароля (переписано с нуля, упрощенная версия)
export function verifyCredentials(login, password) {
  console.log('[AUTH] verifyCredentials called with login:', login);
  
  // Проверяем входные данные
  if (!login || typeof login !== 'string') {
    console.log('[AUTH] Missing or invalid login');
    return null;
  }
  
  if (!password || typeof password !== 'string') {
    console.log('[AUTH] Missing or invalid password');
    return null;
  }
  
  // Проверяем, что база данных инициализирована
  if (!db) {
    console.error('[AUTH] Database object is null');
    throw new Error('Database not initialized');
  }
  
  if (typeof db.prepare !== 'function') {
    console.error('[AUTH] db.prepare is not a function');
    throw new Error('Database prepare method not available');
  }
  
  const trimmedLogin = login.trim();
  console.log(`[AUTH] Looking up user: ${trimmedLogin}`);
  
  // Ищем пользователя по логину
  let user;
  try {
    const query = db.prepare('SELECT id, login, password, display_name, bio, avatar_path FROM users WHERE login = ?');
    user = query.get(trimmedLogin);
    console.log('[AUTH] Query executed, user found:', !!user);
  } catch (dbError) {
    console.error('[AUTH] Database query error:', dbError.message);
    console.error('[AUTH] Database error type:', dbError.constructor.name);
    if (dbError.stack) {
      console.error('[AUTH] Database error stack:', dbError.stack);
    }
    throw new Error('Database query failed: ' + dbError.message);
  }
  
  if (!user) {
    console.log(`[AUTH] User not found: ${trimmedLogin}`);
    return null;
  }
  
  console.log(`[AUTH] User found: ${user.login}, checking password...`);
  
  // Проверяем пароль
  if (user.password !== password) {
    console.log(`[AUTH] Password mismatch for user: ${trimmedLogin}`);
    return null;
  }
  
  // Возвращаем данные пользователя (без пароля)
  console.log(`[AUTH] Successfully authenticated user: ${trimmedLogin}`);
  const result = {
    id: user.id,
    login: user.login,
    displayName: user.display_name,
    bio: user.bio || '',
    avatarPath: user.avatar_path || null,
  };
  console.log('[AUTH] Returning user data:', JSON.stringify(result, null, 2));
  return result;
}
